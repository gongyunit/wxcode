// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
//index.js
//获取应用实例
var app = getApp()
Page({
  data: {
    motto: 'Hello World',
    userInfo: {},
    defaultSize: 'default',
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  gotoDatabind:function() {
    wx.navigateTo({
      url: '../databind/databind'
    })
  },
  gotoList: function () {
    wx.navigateTo({
      url: '../list/list'
    })
  },
  gotoIf: function () {
    wx.navigateTo({
      url: '../if/if'
    })
  },
  gotoTemplate: function () {
    wx.navigateTo({
      url: '../template/template'
    })
  },
  gotoEvent: function () {
    wx.navigateTo({
      url: '../event/event'
    })
  },
  gotoImport: function () {
    wx.navigateTo({
      url: '../import/import'
    })
  },
  onLoad: function () {
    console.log('onLoad')
    var that = this
    //调用应用实例的方法获取全局数据
    app.getUserInfo(function(userInfo){
      //更新数据
      that.setData({
        userInfo:userInfo
      })
    })
  }
})
