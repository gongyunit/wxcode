// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
var util = require('../../utils/util.js')
var interval
Page({
  data: {
    //录音显示类型
    formatRecordTime: '00:00:00',
    //计数
    recordTime: 0,
  },


  onLoad: function (options) {
    // 页面初始化 options为页面跳转所带来的参数
  },
  /**
   * 监听按钮点击开始录音
   */
  listenerButtonStartRecord: function () {
    var that = this;
    interval = setInterval(function () {
      that.data.recordTime += 1
      that.setData({
        //格式化时间显示
        formatRecordTime: util.formatTime(that.data.recordTime)
      })
    }, 1000)
    wx.startRecord({
      success: function (res) {
        console.log(res)
        that.setData({
          //完成之后重新绘制
          formatRecordTime: util.formatTime(that.data.recordTime)
        })
      },
      /**
       * 完成清除定时器
       */
      complete: function () {
        clearInterval(interval)
      }
    })
  },
  /**
   * 监听手动结束录音
   */
  listenerButtonStopRecord: function () {
    wx.stopRecord();
    clearInterval(interval);
    this.setData({
      formatRecordTime: '00:00:00',
      recordTime: 0
    })
  },
  onReady: function () {
    // 页面渲染完成
  },
  onShow: function () {
    // 页面显示
  },
  onHide: function () {
    // 页面隐藏
  },
  /**
   * 当界面关闭时停止定时器关闭录音
   */
  onUnload: function () {
    // 页面关闭
    wx.stopRecord()
    clearInterval(interval)
  }
})
