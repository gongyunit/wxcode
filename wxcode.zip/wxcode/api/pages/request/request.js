// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
Page({
  data: {
    // text:"这是一个页面"
    result: []
  },


  onLoad: function () {
    var that = this;
    wx.request({
      url: 'http://gank.io/api/data/Android/30/1',
      method: 'GET',
      success: function (res) {
        that.setData({
          result: res.data.results
        })
      }
    })
  },
  listenerButton: function () {

  }
})
