// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
//index.js
//获取应用实例
var app = getApp()
Page({
  data: {
  },
  //事件处理函数
  goto: function(event) {
    wx.navigateTo({
      url: event.currentTarget.dataset.link
    })
  },
})
