// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
Page({
  data: {
    // text:"这是一个页面"
    source: ''
  },


  /**
   * 预览图片 又一个奇葩接口
   */
  listenerButtonPreviewImage: function () {
    wx.previewImage({
      current: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1502632193289&di=41d6177c97fa728f3bd506ff27a10228&imgtype=0&src=http%3A%2F%2Fimg2.selfimg.com.cn%2FGQgalleryLowerrightWatermarkB%2F2016%2F08%2F02%2F1470111037_q7b3Dd.jpg',
      urls: [
        'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1502632193289&di=0fd641d90d4e2061fc41d60c25c4b13c&imgtype=0&src=http%3A%2F%2Fwww.cs.com.cn%2Fssgs%2Fkj%2F201708%2FW020170809300947836646.jpg',
        'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1502632193289&di=2bbd77c534a4b521efc6a64d8172195e&imgtype=0&src=http%3A%2F%2Fp0.ifengimg.com%2Fpmop%2F2017%2F0805%2FA3FD8550EDE28301984E406556FC0EFD02BAEB9B_size36_w499_h329.jpeg',
        'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1502632193288&di=f32fce422cb665e5cd1e788851e858fd&imgtype=0&src=http%3A%2F%2Fimage13.m1905.cn%2Fuploadfile%2F2015%2F0301%2F20150301055229958565_watermark.jpg'
      ],
      success: function (res) {
        console.log(res);
      },
      fail: function () {
        console.log('fail')
      }
    })
  }

})
