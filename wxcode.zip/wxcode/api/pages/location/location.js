// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
Page({
  data: {
    text: "Page location"
  },
  onLoad: function (options) {
    // 页面初始化 options为页面跳转所带来的参数
  },
  /**
   * 监听定位到当前位置
   */
  listenerBtnGetLocation: function () {
    wx.getLocation({
      type: 'gcj02', //返回可以用于wx.openLocation的经纬度
      success: function (res) {
        var latitude = res.latitude
        var longitude = res.longitude
        wx.openLocation({
          latitude: latitude,
          longitude: longitude,
          scale: 28
        })
      }
    })
  },
})
