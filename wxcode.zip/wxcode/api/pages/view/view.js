// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
//导入另一个页面
var file = '../image/previewImg'
Page({
  data: {
    text: "Page navigation"
  },
  onLoad: function (options) {
    // 页面初始化 options为页面跳转所带来的参数
  },
  /**
   * 设置NavigationTitle
   */
  setNavigationBarTitle: function () {
    wx.setNavigationBarTitle({
      title: '我是通过API设置的NavigationBarTitle'
    })
  },
  /**
   * 设置加载状态
   */
  showNavigationBarLoading: function () {
    wx.showNavigationBarLoading()
  },
  /**
   * 隐藏加载状态
   */
  hiddenNavigationBarLoading: function () {
    wx.hideNavigationBarLoading()
  },

  /**
   * 保留当前Page跳转
   */
  navigateTo: function () {
    wx.navigateTo({
      //传递参数方式向get请求拼接参数一样
      url: file + '?phone=18939571&password=1992',
      success: function (res) {
        console.log(res)
      },
      fail: function (err) {
        console.log(err)
      }
    })
  },
  /**
   * 关闭当前页面进行跳转当前页面会销毁
   */
  redirectTo: function () {
    wx.redirectTo({
      //传递参数方式向get请求拼接参数一样
      url: file + '?phone=189395719&password=1992'
    })
  },
  /**
   * 退回到上一个页面
   */
  navigateBack: function () {
    wx.navigateBack()
  },
})
