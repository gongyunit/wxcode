// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
Page({
  data: {
    // text:"这是一个页面"
    resource: ''
  },
  onLoad: function (options) {
    // 页面初始化 options为页面跳转所带来的参数
  },
  /**
   * 下载文件
   */
  listenerButtonDownLoadFile: function () {
    var that = this;
    wx.downloadFile({
      url: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1502631864731&di=945b92081e1c7f18c7205e8bafbd1137&imgtype=0&src=http%3A%2F%2Fimg2.selfimg.com.cn%2FGQgalleryLowerrightWatermarkB%2F2016%2F08%2F02%2F1470111037_q7b3Dd.jpg',
      type: 'image',
      success: function (res) {
        console.log(res.tempFilePath);
        that.setData({
          resource: res.tempFilePath,
        })
      },
      fail: function (err) {
        console.log(err)
      },
      complete: function (e) {
        console.log(e)
      }
    })
  }
})
