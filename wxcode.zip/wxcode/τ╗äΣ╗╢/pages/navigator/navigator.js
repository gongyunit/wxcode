// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
Page({
  onLoad: function (options) {
    this.setData({
      title: options.title
    })
  }
})