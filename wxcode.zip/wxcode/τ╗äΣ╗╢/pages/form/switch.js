// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
Page({
  switch1Change: function (e) {
    console.log('switch1 发生 change 事件，携带值为', e.detail.value)
  },
  switch2Change: function (e) {
    console.log('switch2 发生 change 事件，携带值为', e.detail.value)
  }
})